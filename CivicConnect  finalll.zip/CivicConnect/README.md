# CivicConnect — Public Grievance and Complaint Management System

**Tagline:** Your Voice. Your City. Your Change.

CivicConnect is a frontend-only college project prototype. Citizens can register civic complaints, review their records and track status. A demonstration admin view can manage records stored in the current browser.

> **Important:** This is not an official government portal. It does not submit complaints to government departments. Demo admin access is intentionally open and is not secure authentication.

## Features

- Responsive landing page and category cards.
- Citizen complaint form with validation and generated complaint IDs.
- Citizen dashboard with complaint counts, search and status filter.
- Complaint tracking with a five-stage progress display.
- Demo admin dashboard with live totals, category/status charts, table filters, view/edit/delete actions and reset-demo control.
- Browser persistence using LocalStorage and JSON.
- Location suggestions using the OpenStreetMap Nominatim public geocoding service, with manual entry fallback.
- **JAVASCRIPT-CONCEPT-MAPPING.md** documents where each compulsory JavaScript concept is implemented.

## Technologies

HTML5, CSS3, vanilla JavaScript, browser LocalStorage, JSON, Fetch API, async/await and OpenStreetMap Nominatim. No frontend framework or backend is used.

## Folder structure

```text
CivicConnect/
├── index.html
├── citizen-dashboard.html
├── complaint-form.html
├── track-complaint.html
├── admin-dashboard.html
├── README.md
├── JAVASCRIPT-CONCEPT-MAPPING.md
├── css/
│   └── style.css
├── js/
│   ├── app.js
│   ├── complaints.js
│   ├── citizen.js
│   ├── admin.js
│   └── location.js
└── assets/
    └── (reserved for optional project assets)
```

## Run in VS Code on a Mac

1. Download and unzip `CivicConnect.zip`.
2. Open VS Code.
3. Select **File → Open Folder…** and choose the extracted `CivicConnect` folder.
4. Open `index.html`.
5. Run it using the VS Code **Live Server** extension (right-click `index.html` → **Open with Live Server**). If Live Server is not installed, install it from the Extensions panel.
6. Your browser should open the homepage. Navigate using the top menu.

Using a local server is recommended for consistent browser behaviour. An internet connection is needed for Google Fonts and location suggestions; the rest of the demo works without the location API.

## How to test the prototype

### 1. Register a complaint
- Open **Register a complaint**.
- Enter a name, a 10-digit Indian mobile number, a valid email, category, title, description and location.
- Try submitting empty or invalid values to see field-level validation.
- Submit a valid report. The app displays a generated ID such as `CC-2026-1006`.

### 2. Confirm LocalStorage persistence
- Open the Citizen dashboard and find your new record.
- Refresh the browser. The record should remain.
- Records are stored under the browser key `civicconnect_complaints_v1`.

### 3. Track a complaint
- Open **Track complaint** and enter the generated ID.
- The complaint details and status tracker appear.
- Unknown IDs show a friendly error.
- Admin status changes are reflected when the tracking page is opened or refreshed.

### 4. Demo admin dashboard
- Choose **Admin demo** in the navigation.
- There is no password: this is clearly labelled demo access, not authentication.
- Use search, category and status filters.
- Select **View** to inspect a record or **Edit** to update its details/status.
- Select **Delete** and confirm to remove a record.
- Select **Reset demo data** to restore the original sample records. This removes locally added records and resets edits.

### 5. Location lookup
- On the complaint form, type at least three characters in Location.
- Matching OpenStreetMap place suggestions appear after a short delay.
- Select a suggestion or type a location manually.
- If the service or network is unavailable, an error/fallback message appears and the rest of the form remains usable.

## How LocalStorage works here

`js/complaints.js` maintains an array of complaint objects. `saveComplaints()` serializes the array with `JSON.stringify()` and stores it in LocalStorage. `loadComplaints()` reads it and uses `JSON.parse()` on the next page load. LocalStorage belongs to the browser and origin, so records are not shared between different browsers/devices and may be cleared by clearing browser site data.

## Complaint statuses

1. Submitted
2. Under Review
3. Assigned
4. In Progress
5. Resolved

The dashboard's **Pending** total includes Submitted, Under Review and Assigned. In Progress and Resolved are counted separately.

## Sample data

The first visit seeds five clearly identifiable sample records. Use the reset button on the admin dashboard to restore them. New reports are stored alongside these samples.

## Limitations

- Frontend-only: no server, database, email/SMS notification or municipal integration.
- Admin demo has no secure authentication or authorisation.
- Data exists only in the current browser's LocalStorage.
- The optional image input records only the selected filename; it does not upload or persist the image file.
- Nominatim is a public service. Availability, response time and usage policies are controlled by OpenStreetMap; location suggestions are optional and manual entry remains available.
- The status updates are demonstration actions, not real-world government workflow updates.

## JavaScript concept mapping

Read **[JAVASCRIPT-CONCEPT-MAPPING.md](JAVASCRIPT-CONCEPT-MAPPING.md)** for the exact file, function, explanation and code example for every mandatory academic concept.

## Project identity

**CivicConnect — Public Grievance and Complaint Management System**  
*Your Voice. Your City. Your Change.*
