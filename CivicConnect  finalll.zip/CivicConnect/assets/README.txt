Optional images/icons can be placed here. The current prototype uses CSS-drawn visuals and text symbols, so no external image assets are required.
