# JAVASCRIPT CONCEPT MAPPING — CIVICCONNECT

This document maps each required JavaScript concept to working code in this project. The examples below are shortened excerpts; open the named file to see the complete implementation.

| Mandatory concept | JavaScript file | Function / implementation |
|---|---|---|
| DOM manipulation | `js/citizen.js`, `js/admin.js`, `js/location.js`, `js/app.js` | `renderCitizenDashboard()`, `renderAdmin()`, `renderCharts()`, `searchLocation()`, shared `DOMContentLoaded` setup |
| Arrays of objects | `js/complaints.js` | `DEMO_RECORDS` and the `complaints` array |
| `forEach()` | `js/citizen.js`, `js/admin.js` | `renderCitizenDashboard()`, `renderAdmin()`, `renderCharts()` |
| `filter()` | `js/complaints.js`, `js/admin.js` | `filterComplaints()`, admin view filtering |
| Form validation | `js/citizen.js` | `validate()` inside `setupComplaintForm()`; admin edit validation in `openEdit()` |
| CRUD operations | `js/complaints.js`, `js/admin.js`, `js/citizen.js` | `addComplaint()`, `getComplaints()` / `getComplaintById()`, `updateComplaint()`, `deleteComplaint()` |
| LocalStorage + JSON | `js/complaints.js` | `loadComplaints()`, `saveComplaints()` |
| Fetch API + async JavaScript | `js/location.js` | `searchLocation()` |
| Dynamic dashboard statistics | `js/complaints.js`, `js/admin.js`, `js/citizen.js`, `js/app.js` | `getSummary()`, `renderAdmin()`, `renderCitizenDashboard()`, shared homepage setup |
| Separate, readable JavaScript files | `js/*.js` | Data, shared setup, citizen views, admin views and location lookup are separated by responsibility |

## 1. DOM manipulation

**Where:** `js/citizen.js` → `renderCitizenDashboard()`; `js/admin.js` → `renderAdmin()` and `renderCharts()`; `js/location.js` → `searchLocation()`.

**How it works:** JavaScript selects existing page elements, creates new complaint cards, table rows and suggestion buttons, then inserts user-facing text and listens for interactions. The complaint records are not hardcoded as HTML cards or rows.

```js
const container = document.getElementById("citizen-complaints");
const card = document.createElement("article");
card.textContent = record.title;
container.appendChild(card);
```

The project also uses `querySelector()` for field errors and navigation, `innerHTML` to clear/rebuild dynamic containers, `textContent` for safe text insertion, and `addEventListener()` for user actions.

## 2. Arrays of objects

**Where:** `js/complaints.js` → `DEMO_RECORDS`, `complaints`.

**How it works:** Each complaint is a JavaScript object with the required fields: `complaintId`, `citizenName`, `contact`, `email`, `category`, `title`, `description`, `location`, `date` and `status`. New submissions are added to the same array.

```js
const complaint = {
  complaintId: "CC-2026-1001",
  citizenName: "Aarav Mehta",
  contact: "9876543210",
  email: "aarav@example.com",
  category: "Roads",
  title: "Pothole near community park",
  description: "A pothole needs attention.",
  location: "Kukatpally, Hyderabad",
  date: "2026-11-14",
  status: "In Progress"
};
```

## 3. `forEach()`

**Where:** `js/citizen.js` → `renderCitizenDashboard()`; `js/admin.js` → `renderAdmin()` and `renderCharts()`.

**How it works:** The filtered array is looped through to create a visible card or table row for every record.

```js
records.forEach(record => {
  const row = document.createElement("tr");
  // Create cells and add the record's values.
  tableBody.appendChild(row);
});
```

## 4. `filter()`

**Where:** `js/complaints.js` → `filterComplaints()`.

**How it works:** Category, status and search text are combined into conditions. The page re-renders on input/change events, without a browser refresh.

```js
return complaints.filter(item =>
  (!category || item.category === category) &&
  (!status || item.status === status) &&
  (!term || item.title.toLowerCase().includes(term))
);
```

## 5. Form validation

**Where:** `js/citizen.js` → `validate()` inside `setupComplaintForm()`.

**How it works:** Required fields are checked. Name and title lengths, Indian 10-digit mobile format, email format and description length are checked. Errors are displayed next to the relevant field. The form is saved only if all checks pass.

```js
if (id === "contact" && !/^[6-9]\\d{9}$/.test(value)) {
  message = "Enter a valid 10-digit Indian mobile number.";
}
```

## 6. CRUD operations

**Where:** `js/complaints.js` → `addComplaint()`, `getComplaints()`, `getComplaintById()`, `updateComplaint()`, `deleteComplaint()`.

**How it works:** The citizen form creates a record; citizen/admin pages read records; admin edit updates fields and status; admin delete asks for confirmation before removing a record.

```js
function updateComplaint(id, changes) {
  const index = complaints.findIndex(item => item.complaintId === id);
  if (index < 0) return null;
  complaints[index] = { ...complaints[index], ...changes };
  saveComplaints();
}
```

## 7. LocalStorage and JSON

**Where:** `js/complaints.js` → `loadComplaints()` and `saveComplaints()`.

**How it works:** `JSON.stringify()` converts the array into text before it is saved. On page load, `JSON.parse()` converts saved text back into an array. This keeps records after refresh in the same browser.

```js
localStorage.setItem(STORAGE_KEY, JSON.stringify(complaints));
const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY));
```

## 8. Fetch API and asynchronous JavaScript

**Where:** `js/location.js` → `searchLocation()`.

**How it works:** After the user types at least three characters, the app waits briefly, requests matching place names from OpenStreetMap Nominatim, and displays suggestions. `async/await` waits for the response; `try/catch` handles network/API errors. A loading message is displayed while searching.

```js
async function searchLocation(query) {
  loading.textContent = "Searching map locations…";
  try {
    const response = await fetch(endpoint);
    if (!response.ok) throw new Error("Location service unavailable");
    const results = await response.json();
  } catch (error) {
    loading.textContent = "Enter your location manually.";
  }
}
```

## 9. Dynamic dashboard statistics

**Where:** `js/complaints.js` → `getSummary()`; `js/admin.js` → `renderAdmin()`; `js/citizen.js` → `renderCitizenDashboard()`; `js/app.js` → homepage setup.

**How it works:** Counts are calculated from the current complaint array. The admin and citizen dashboard re-render after CRUD operations, so totals and charts reflect the latest records.

```js
const total = complaints.length;
const resolved = complaints.filter(item => item.status === "Resolved").length;
```

## 10. Code organisation

- `complaints.js`: single source of truth for records, storage, filters and CRUD.
- `app.js`: shared navigation and homepage figures.
- `citizen.js`: form validation, citizen complaint list and tracking.
- `admin.js`: admin table, filters, edit/delete, charts and summary.
- `location.js`: external location search only.

## Demonstration checklist

1. Open `complaint-form.html`, submit a valid complaint, and note its generated ID.
2. Refresh the page or open `citizen-dashboard.html`; confirm the record remains.
3. Search for the ID in `track-complaint.html`.
4. Open `admin-dashboard.html`, edit the record and change its status.
5. Return to tracking and confirm the new status is shown.
6. Delete the record from the admin table after confirming the prompt.
7. Try category, status and search filters.
8. Try location lookup with an internet connection, then test manual entry if the service is unavailable.

**Academic honesty note:** This is a frontend-only browser prototype. It does not send complaints to a municipality, provide secure authentication, or use a backend database.
