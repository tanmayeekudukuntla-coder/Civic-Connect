/* Shared page setup and dynamic dashboard numbers. */
document.addEventListener("DOMContentLoaded", () => {
  const menuButton = document.querySelector(".menu-toggle");
  const navigation = document.querySelector(".main-nav");
  if (menuButton && navigation) menuButton.addEventListener("click", () => navigation.classList.toggle("open"));
  if (!window.CivicData) return;
  const summary = CivicData.getSummary();
  const mappings = {"home-total":"total","home-pending":"pending","home-progress":"inProgress","home-resolved":"resolved","hero-total":"total"};
  Object.entries(mappings).forEach(([id,key]) => {
    const element = document.getElementById(id);
    if (element) element.textContent = summary[key];
  });
});