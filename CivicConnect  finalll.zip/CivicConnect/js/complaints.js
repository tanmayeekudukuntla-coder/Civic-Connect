/* Core data layer: array of objects, JSON and LocalStorage, CRUD and filtering. */
(function () {
  "use strict";
  const STORAGE_KEY = "civicconnect_complaints_v1";
  const DEMO_RECORDS = [
    {complaintId:"CC-2026-1001",citizenName:"Aarav Mehta",contact:"9876543210",email:"aarav@example.com",category:"Roads",title:"Pothole near community park",description:"A large pothole has formed near the main entrance of the community park and needs attention.",location:"Kukatpally, Hyderabad, Telangana",date:"2026-11-14",status:"In Progress",isDemo:true},
    {complaintId:"CC-2026-1002",citizenName:"Diya Reddy",contact:"9123456780",email:"diya@example.com",category:"Water Supply",title:"Irregular water supply",description:"Water supply has been irregular in our lane for the past few days.",location:"Miyapur, Hyderabad, Telangana",date:"2026-11-15",status:"Under Review",isDemo:true},
    {complaintId:"CC-2026-1003",citizenName:"Kabir Shah",contact:"9988776655",email:"kabir@example.com",category:"Sanitation",title:"Waste collection missed",description:"The scheduled waste collection was missed this week.",location:"Ameerpet, Hyderabad, Telangana",date:"2026-11-16",status:"Resolved",isDemo:true},
    {complaintId:"CC-2026-1004",citizenName:"Ira Nair",contact:"9000012345",email:"ira@example.com",category:"Electricity",title:"Streetlight not working",description:"The streetlight near the bus stop has not been working.",location:"SR Nagar, Hyderabad, Telangana",date:"2026-11-17",status:"Submitted",isDemo:true},
    {complaintId:"CC-2026-1005",citizenName:"Rehan Ali",contact:"9090909090",email:"rehan@example.com",category:"Drainage",title:"Blocked roadside drain",description:"The roadside drain appears blocked and water is collecting after rain.",location:"Banjara Hills, Hyderabad, Telangana",date:"2026-11-18",status:"Assigned",isDemo:true}
  ];
  const STATUS_STAGES = ["Submitted", "Under Review", "Assigned", "In Progress", "Resolved"];
  function loadComplaints() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored === null) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(DEMO_RECORDS));
        return DEMO_RECORDS.map(item => ({...item}));
      }
      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.error("Could not read complaint records:", error);
      return [];
    }
  }
  let complaints = loadComplaints();
  function saveComplaints() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(complaints));
  }
  function getComplaints() { return complaints.map(item => ({...item})); }
  function getComplaintById(id) { return complaints.find(item => item.complaintId.toLowerCase() === String(id).trim().toLowerCase()) || null; }
  function generateComplaintId() {
    const highest = complaints.reduce((max, item) => {
      const number = Number(String(item.complaintId).split("-").pop());
      return Number.isFinite(number) ? Math.max(max, number) : max;
    }, 1000);
    return `CC-${new Date().getFullYear()}-${highest + 1}`;
  }
  function addComplaint(data) {
    const record = {...data, complaintId:generateComplaintId(), date:new Date().toISOString().slice(0,10), status:"Submitted", isDemo:false};
    complaints.unshift(record); saveComplaints(); return {...record};
  }
  function updateComplaint(id, changes) {
    const index = complaints.findIndex(item => item.complaintId === id);
    if (index < 0) return null;
    complaints[index] = {...complaints[index], ...changes, complaintId:id};
    saveComplaints(); return {...complaints[index]};
  }
  function deleteComplaint(id) {
    const before = complaints.length;
    complaints = complaints.filter(item => item.complaintId !== id);
    if (complaints.length !== before) saveComplaints();
    return complaints.length !== before;
  }
  function filterComplaints({category="", status="", search=""} = {}) {
    const term = search.trim().toLowerCase();
    return complaints.filter(item => {
      const categoryMatch = !category || item.category === category;
      const statusMatch = !status || item.status === status;
      const searchMatch = !term || [item.complaintId,item.citizenName,item.title,item.location,item.category].some(value => String(value || "").toLowerCase().includes(term));
      return categoryMatch && statusMatch && searchMatch;
    });
  }
  function resetDemoData() {
    complaints = DEMO_RECORDS.map(item => ({...item}));
    saveComplaints(); return getComplaints();
  }
  function getSummary() {
    return {
      total:complaints.length,
      pending:complaints.filter(item => ["Submitted","Under Review","Assigned"].includes(item.status)).length,
      inProgress:complaints.filter(item => item.status === "In Progress").length,
      resolved:complaints.filter(item => item.status === "Resolved").length
    };
  }
  window.CivicData = {STATUS_STAGES, getComplaints, getComplaintById, addComplaint, updateComplaint, deleteComplaint, filterComplaints, resetDemoData, getSummary};
})();