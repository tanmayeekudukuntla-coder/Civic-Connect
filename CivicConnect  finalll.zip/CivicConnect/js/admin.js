/* Admin CRUD interface, filters, dynamic statistics and CSS-based charts. */
document.addEventListener("DOMContentLoaded", () => {
  const tableBody = document.getElementById("admin-table-body");
  if (!tableBody) return;
  let currentView = "all";
  const search = document.getElementById("admin-search");
  const category = document.getElementById("admin-category");
  const status = document.getElementById("admin-status");
  [search,category,status].forEach(control => control.addEventListener("input", renderAdmin));
  document.querySelectorAll("[data-view]").forEach(link => link.addEventListener("click", () => {
    currentView = link.dataset.view;
    document.querySelectorAll("[data-view]").forEach(item => item.classList.toggle("active", item === link));
    document.getElementById("table-title").textContent = currentView === "pending" ? "Pending complaints" : currentView === "resolved" ? "Resolved complaints" : "All complaints";
    renderAdmin();
  }));
  document.getElementById("reset-demo").addEventListener("click", () => {
    if (confirm("Reset all records to the original sample demo data? Your added records and edits will be lost.")) { CivicData.resetDemoData(); renderAdmin(); }
  });
  const modal = document.getElementById("complaint-modal");
  document.getElementById("modal-close").addEventListener("click", closeModal);
  modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });
  function closeModal(){modal.hidden = true;}
  function openDetails(record) {
    const content = document.getElementById("modal-content"); content.innerHTML = "";
    const grid = document.createElement("div"); grid.className = "detail-grid";
    [["Complaint ID",record.complaintId],["Citizen",record.citizenName],["Contact",record.contact],["Email",record.email],["Category",record.category],["Location",record.location],["Date",record.date],["Status",record.status]].forEach(([label,value]) => {
      const item = document.createElement("div"); item.className = "detail-item";
      const name = document.createElement("span"); name.textContent = label;
      const val = document.createElement("b"); val.textContent = value || "—"; item.append(name,val); grid.appendChild(item);
    });
    const description = document.createElement("p"); description.className = "detail-description"; description.textContent = record.description;
    const edit = document.createElement("button"); edit.className = "button button-small"; edit.textContent = "Edit complaint";
    edit.addEventListener("click", () => openEdit(CivicData.getComplaintById(record.complaintId)));
    content.append(grid,description,edit); modal.hidden = false;
  }
  function openEdit(record) {
    if (!record) return;
    document.getElementById("modal-title").textContent = "Edit complaint";
    const content = document.getElementById("modal-content"); content.innerHTML = "";
    const form = document.createElement("form"); form.className = "edit-form";
    const fields = [
      ["citizenName","Citizen name","text"],["contact","Contact number","tel"],["email","Email address","email"],
      ["title","Complaint title","text"],["location","Location","text"],["description","Description","textarea"]
    ];
    fields.forEach(([name,label,type]) => {
      const wrap = document.createElement("label"); wrap.textContent = label;
      const input = type === "textarea" ? document.createElement("textarea") : document.createElement("input");
      input.name = name; input.value = record[name] || ""; input.required = true;
      wrap.appendChild(input); form.appendChild(wrap);
    });
    const categoryLabel = document.createElement("label"); categoryLabel.textContent = "Category";
    const categorySelect = document.createElement("select"); categorySelect.name = "category";
    ["Water Supply","Electricity","Roads","Sanitation","Drainage","Other"].forEach(value => {
      const option = document.createElement("option"); option.value = value; option.textContent = value; categorySelect.appendChild(option);
    });
    categorySelect.value = record.category; categoryLabel.appendChild(categorySelect); form.appendChild(categoryLabel);
    const statusLabel = document.createElement("label"); statusLabel.textContent = "Complaint status";
    const statusSelect = document.createElement("select"); statusSelect.name = "status";
    CivicData.STATUS_STAGES.forEach(value => {const option=document.createElement("option");option.value=value;option.textContent=value;statusSelect.appendChild(option);});
    statusSelect.value = record.status; statusLabel.appendChild(statusSelect); form.appendChild(statusLabel);
    const actions = document.createElement("div"); actions.className = "modal-actions";
    const cancel = document.createElement("button"); cancel.type = "button"; cancel.className = "button button-muted button-small"; cancel.textContent = "Cancel"; cancel.addEventListener("click", () => openDetails(CivicData.getComplaintById(record.complaintId)));
    const save = document.createElement("button"); save.type = "submit"; save.className = "button button-small"; save.textContent = "Save changes";
    actions.append(cancel,save); form.appendChild(actions);
    form.addEventListener("submit", event => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      if (!/^[6-9]\d{9}$/.test(data.contact) || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email)) {alert("Please enter a valid 10-digit mobile number and email address.");return;}
      CivicData.updateComplaint(record.complaintId,data); renderAdmin(); closeModal();
    });
    content.appendChild(form); document.getElementById("modal-title").textContent = "Edit complaint"; modal.hidden = false;
  }
  function renderAdmin() {
    const summary = CivicData.getSummary();
    [["admin-total","total"],["admin-pending","pending"],["admin-progress","inProgress"],["admin-resolved","resolved"]].forEach(([id,key]) => document.getElementById(id).textContent = summary[key]);
    let records = CivicData.filterComplaints({category:category.value,status:status.value,search:search.value});
    if (currentView === "pending") records = records.filter(item => ["Submitted","Under Review","Assigned"].includes(item.status));
    if (currentView === "resolved") records = records.filter(item => item.status === "Resolved");
    tableBody.innerHTML = "";
    records.forEach(record => {
      const row = document.createElement("tr");
      const idCell = document.createElement("td"); idCell.innerHTML = `<span class="table-id"></span>`; idCell.querySelector("span").textContent = record.complaintId;
      const citizenCell = document.createElement("td"); citizenCell.textContent = record.citizenName;
      const categoryCell = document.createElement("td"); categoryCell.textContent = record.category;
      const title = document.createElement("span"); title.className = "table-title"; title.textContent = record.title; categoryCell.appendChild(title);
      const locationCell = document.createElement("td"); locationCell.textContent = record.location;
      const dateCell = document.createElement("td"); dateCell.textContent = record.date;
      const statusCell = document.createElement("td"); const badge = document.createElement("span"); badge.className = `status-badge status-${record.status.toLowerCase().replaceAll(" ","-")}`; badge.textContent = record.status; statusCell.appendChild(badge);
      const actionCell = document.createElement("td"); const actions = document.createElement("div"); actions.className = "table-actions";
      const view = document.createElement("button"); view.textContent = "View"; view.addEventListener("click", () => openDetails(record));
      const edit = document.createElement("button"); edit.textContent = "Edit"; edit.addEventListener("click", () => openEdit(record));
      const remove = document.createElement("button"); remove.textContent = "Delete"; remove.className = "delete-action"; remove.addEventListener("click", () => {
        if (confirm(`Delete complaint ${record.complaintId}? This cannot be undone.`)) { CivicData.deleteComplaint(record.complaintId); renderAdmin(); }
      });
      actions.append(view,edit,remove); actionCell.appendChild(actions);
      row.append(idCell,citizenCell,categoryCell,locationCell,dateCell,statusCell,actionCell); tableBody.appendChild(row);
    });
    document.getElementById("admin-empty").hidden = records.length !== 0;
    renderCharts(CivicData.getComplaints());
  }
  function renderCharts(records) {
    const categoryCounts = ["Water Supply","Electricity","Roads","Sanitation","Drainage","Other"].map(name => ({name,count:records.filter(item => item.category === name).length}));
    const maxCategory = Math.max(1,...categoryCounts.map(item => item.count));
    const categoryChart = document.getElementById("category-chart"); categoryChart.innerHTML = "";
    categoryCounts.forEach(item => {
      const row = document.createElement("div"); row.className = "bar-row";
      const label = document.createElement("span"); label.textContent = item.name;
      const track = document.createElement("div"); track.className = "bar-track";
      const fill = document.createElement("div"); fill.className = "bar-fill"; fill.style.width = `${item.count/maxCategory*100}%`; track.appendChild(fill);
      const count = document.createElement("b"); count.className = "bar-count"; count.textContent = item.count;
      row.append(label,track,count); categoryChart.appendChild(row);
    });
    const statusChart = document.getElementById("status-chart"); statusChart.innerHTML = "";
    CivicData.STATUS_STAGES.forEach(stage => {
      const count = records.filter(item => item.status === stage).length;
      const column = document.createElement("div"); column.className = "status-column";
      const number = document.createElement("b"); number.textContent = count;
      const fill = document.createElement("div"); fill.className = "column-fill"; fill.style.height = `${Math.max(3,count/Math.max(1,records.length)*78)}px`;
      const label = document.createElement("small"); label.textContent = stage;
      column.append(number,fill,label); statusChart.appendChild(column);
    });
  }
  renderAdmin();
});