/* Public Nominatim geocoding demo. The form remains usable if the API is unavailable. */
document.addEventListener("DOMContentLoaded", () => {
  const locationInput = document.getElementById("location");
  const loading = document.getElementById("location-loading");
  const suggestions = document.getElementById("location-suggestions");
  if (!locationInput || !loading || !suggestions) return;
  let debounceTimer;
  locationInput.addEventListener("input", () => {
    clearTimeout(debounceTimer);
    suggestions.innerHTML = "";
    const query = locationInput.value.trim();
    if (query.length < 3) { loading.textContent = ""; return; }
    debounceTimer = setTimeout(() => searchLocation(query), 550);
  });
  async function searchLocation(query) {
    loading.textContent = "Searching map locations…";
    try {
      const endpoint = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&q=${encodeURIComponent(query)}`;
      const response = await fetch(endpoint, {headers:{"Accept":"application/json"}});
      if (!response.ok) throw new Error(`Location service returned ${response.status}`);
      const results = await response.json();
      loading.textContent = results.length ? "Choose a suggested location, or keep your own text." : "No matching location found. You can still enter it manually.";
      results.forEach(result => {
        const option = document.createElement("button");
        option.type = "button"; option.className = "suggestion";
        option.textContent = result.display_name;
        option.addEventListener("click", () => {
          locationInput.value = result.display_name;
          suggestions.innerHTML = ""; loading.textContent = "Location selected.";
        });
        suggestions.appendChild(option);
      });
    } catch (error) {
      console.error("Location lookup failed:", error);
      loading.textContent = "Location search is unavailable right now. Enter your location manually.";
    }
  }
});