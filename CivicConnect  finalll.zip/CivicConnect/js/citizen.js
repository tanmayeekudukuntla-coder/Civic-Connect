/* Citizen complaint form, citizen dashboard and tracking page. */
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("complaint-form");
  if (form) setupComplaintForm(form);
  renderCitizenDashboard();
  setupTracking();
  const search = document.getElementById("citizen-search");
  const status = document.getElementById("citizen-status");
  if (search) search.addEventListener("input", renderCitizenDashboard);
  if (status) status.addEventListener("change", renderCitizenDashboard);
});
function setupComplaintForm(form) {
  const params = new URLSearchParams(window.location.search);
  const category = document.getElementById("category");
  if (params.has("category") && category) category.value = params.get("category");
  const fields = ["citizenName","contact","email","category","title","location","description"];
  function validate() {
    let valid = true;
    fields.forEach(id => {
      const field = document.getElementById(id);
      const error = document.querySelector(`[data-error="${id}"]`);
      let message = "";
      const value = field.value.trim();
      if (!value) message = "This field is required.";
      else if (id === "citizenName" && value.length < 2) message = "Enter at least 2 characters.";
      else if (id === "contact" && !/^[6-9]\d{9}$/.test(value)) message = "Enter a valid 10-digit Indian mobile number.";
      else if (id === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) message = "Enter a valid email address.";
      else if (id === "title" && value.length < 5) message = "Title should contain at least 5 characters.";
      else if (id === "description" && value.length < 15) message = "Please add at least 15 characters of detail.";
      if (error) error.textContent = message;
      field.setAttribute("aria-invalid", message ? "true" : "false");
      if (message) valid = false;
    });
    return valid;
  }
  fields.forEach(id => document.getElementById(id).addEventListener("input", () => {
    const error = document.querySelector(`[data-error="${id}"]`);
    if (error) error.textContent = "";
  }));
  form.addEventListener("submit", event => {
    event.preventDefault();
    const message = document.getElementById("form-message");
    if (!validate()) {
      message.className = "message error"; message.textContent = "Please review the highlighted fields before submitting."; return;
    }
    const record = CivicData.addComplaint({
      citizenName:document.getElementById("citizenName").value.trim(),
      contact:document.getElementById("contact").value.trim(),
      email:document.getElementById("email").value.trim(),
      category:document.getElementById("category").value,
      title:document.getElementById("title").value.trim(),
      description:document.getElementById("description").value.trim(),
      location:document.getElementById("location").value.trim(),
      attachmentName:document.getElementById("attachment").files[0]?.name || ""
    });
    message.className = "message success";
    message.textContent = `Your demo complaint has been saved. Your reference ID is ${record.complaintId}. Save this ID to track its status.`;
    form.reset();
    document.getElementById("location-loading").textContent = "";
    document.getElementById("location-suggestions").innerHTML = "";
    window.scrollTo({top:form.offsetTop - 100,behavior:"smooth"});
  });
}
function renderCitizenDashboard() {
  const container = document.getElementById("citizen-complaints");
  if (!container || !window.CivicData) return;
  const summary = CivicData.getSummary();
  [["citizen-total","total"],["citizen-pending","pending"],["citizen-progress","inProgress"],["citizen-resolved","resolved"]].forEach(([id,key]) => {
    const el = document.getElementById(id); if (el) el.textContent = summary[key];
  });
  const search = document.getElementById("citizen-search")?.value || "";
  const status = document.getElementById("citizen-status")?.value || "";
  const records = CivicData.filterComplaints({search,status});
  container.innerHTML = "";
  records.forEach(record => {
    const card = document.createElement("article"); card.className = "complaint-card";
    const main = document.createElement("div"); main.className = "complaint-main";
    const id = document.createElement("span"); id.className = "id-line"; id.textContent = record.complaintId;
    const title = document.createElement("h3"); title.textContent = record.title;
    const meta = document.createElement("p"); meta.textContent = `${record.category} · ${record.location} · ${record.date}`;
    main.append(id,title,meta);
    const right = document.createElement("div"); right.className = "complaint-meta";
    const badge = document.createElement("span"); badge.className = `status-badge status-${record.status.toLowerCase().replaceAll(" ","-")}`; badge.textContent = record.status;
    const link = document.createElement("a"); link.className = "text-link"; link.href = `track-complaint.html?id=${encodeURIComponent(record.complaintId)}`; link.textContent = "Track →";
    right.append(badge,link); card.append(main,right); container.appendChild(card);
  });
  const empty = document.getElementById("citizen-empty");
  if (empty) empty.hidden = records.length !== 0;
}
function setupTracking() {
  const form = document.getElementById("track-form");
  if (!form) return;
  const input = document.getElementById("track-id");
  const result = document.getElementById("track-result");
  const message = document.getElementById("track-message");
  function track(id) {
    const record = CivicData.getComplaintById(id);
    result.hidden = true; result.innerHTML = ""; message.className = "message";
    if (!record) { message.className = "message error"; message.textContent = "We couldn't find that complaint ID. Check the ID and try again."; return; }
    message.textContent = "";
    const title = document.createElement("h2"); title.textContent = record.title;
    const idLine = document.createElement("div"); idLine.className = "track-id"; idLine.textContent = record.complaintId;
    const details = document.createElement("div"); details.className = "track-details";
    [["Category",record.category],["Location",record.location],["Submitted",record.date],["Citizen",record.citizenName],["Current status",record.status]].forEach(([label,value]) => {
      const item = document.createElement("div"); const span = document.createElement("span"); span.textContent = label;
      const strong = document.createElement("b"); strong.textContent = value; item.append(span,strong); details.appendChild(item);
    });
    const progress = document.createElement("div"); progress.className = "progress-track";
    const currentIndex = CivicData.STATUS_STAGES.indexOf(record.status);
    CivicData.STATUS_STAGES.forEach((stage,index) => {
      const step = document.createElement("div"); step.className = `progress-step${index <= currentIndex ? " done" : ""}`;
      const dot = document.createElement("i"); dot.textContent = index < currentIndex ? "✓" : String(index+1);
      const label = document.createElement("span"); label.textContent = stage;
      step.append(dot,label); progress.appendChild(step);
    });
    const note = document.createElement("p"); note.className = "field-hint"; note.textContent = "Status shown here reflects the records in this browser's academic demo.";
    result.append(idLine,title,details,progress,note); result.hidden = false;
  }
  form.addEventListener("submit", event => {event.preventDefault(); track(input.value);});
  const params = new URLSearchParams(window.location.search);
  if (params.has("id")) {input.value = params.get("id"); track(input.value);}
}